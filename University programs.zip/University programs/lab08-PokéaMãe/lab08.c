/*Leonardo Falcao Sabra-RA178441
  Lab08-PokeaMae
  Entrada: inteiro indicando numero de evolucoes de mostro para a base de dados, 
           identificador da especie de monstro com o poder antes da evolucao e depois da evolucao (na base de dados),
           e novamente identificador da especie e poder antes da evolucao (para consulta)   
  Saida: poder estimado futuro (para as entradas da consulta)
  Objetivo: estimar o poder de um monstro apos a evolucao baseado em dados de uma tabela com resulatdos das evolucoes ja experimentados no passado */
  
#include <stdio.h>
#include <math.h>
int main()
{
	int N; /*auxiliar para numero de linhas para base de dados*/
	int i; /*numero da especie i, que vai de 0 ate no maximo 150, criada pelo programa*/
	int esp[151]; /*variavel que vai criar um identificador para a especie i baseada em um monstro do jogo*/
	int I; /*variavel do identificador da especie de monstro do jogo*/
	int PCa, PCf[151]; /*poder de combate atual(PCa) e futuro (PCf)*/
	int j; /*auxiliar para comparar especies e para guardar PCf desejado*/
	int m=1, c=0; /*auxiliar para calculo do multiplicador medio(m) e auxiliar para imprimir na tela(c)*/
	float M[151]; /*auxiliar para calculo do multiplicador*/
		
	scanf("%d", &N); /*ler numero de evolucoes de monstros presentes na base de dados*/
	
	/*Criar especies i, de 0 ate N, no programa*/
	for(i=0;i<N;i++)
	{
		scanf("%d %d %d", &esp[i], &PCa, &PCf[i]); /*Atribuir um identificador(esp[i]) para a especie i e um PCa e PCf*/
		M[i] = (float) PCf[i] / (float) PCa; /*Calcular o multiplicador para a especie i*/
	}
	
	/*Fazer as especies com o mesmo identificador(esp[i]) serem a mesma especie i*/
	for(i=0;i<N;i++)
	{
		/*Comparar os identificadores das especies i*/
		if(esp[i]!=0) /*Impedir que compare especies que nao existem(identificador zero)*/
		{
			for(j=i+1;j<N;j++)
			{
				if(esp[j]==esp[i]) /*Se a especie j tem mesmo identificador da especie i, entao ela devem ser a mesma especie i*/
				{
					M[i]=M[i]+M[j]; /*Guardar a soma dor multiplicadores obtidos para especie i*/
					m++; /*Guardar a quantidade de multiplicadores obtidos para a especie i*/
					esp[j]=0; /*Impedir que tenha duas especies com dois numeros i e j diferentes e com mesmo 
					          identificador, fazendo que uma delas nao exista(tenha identificador zero)*/
				}
			}
			M[i]=M[i]/m;/*Calcular o multiplicador medio (M[i]) para a especie i*/
			m=1; /*Reiniciar a contagem dos multiplicadores para uma nova especie*/
		}
	}
	/*Agora foi feito a base de dados para cada especie i com identificador esp[i] que � a mesma especie de monstro do jogo que tem identificador I=esp[i]*/

	scanf("%d %d", &I, &PCa); /*ler identificador da especie de monstro*/
			
    for(j=0;I!=0;j++) /*Guadar os PCf desejados em PCf[j] com j variando de 0 a c-1*/
	{
		for(i=0;i<N;i++)
		{
			if(I==esp[i]) /*achar qual especie do programa � a mesma especie do monstro do jogo*/
			{
				PCf[j]=ceil(M[i]*PCa); /*calcular PCf para a especie do monstro solicitada e arredondar para cima*/
		   	}
	    }
	   	c++; /*contagem do numero de consultas do PCf que foram feitas*/
	    scanf("%d %d", &I, &PCa); 
	}
		
	for(i=0;i<c;i++)
	{
		printf("%d\n", PCf[i]); /*imprimir na tela os PCf estimado*/
	}

	
	return 0;
}
