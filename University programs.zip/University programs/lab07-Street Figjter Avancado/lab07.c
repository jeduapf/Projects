/*Leonardo Falcao Sabra-RA178441
  Lab07-Street Fighter Avancado
  Entrada: nuemros inteiros que representam golpes aplicados por Ryu, valores positivos, e Ken, valores negativos
  Saida: resultado da luta, quem venceu ou se houve empate
  Objetivo: determinar quem venceu a luta considerando os multiplicadores de danos*/
  
#include <stdio.h>
int main()
{
	int g; /*variavel de entrada que indica os golpes*/
	int pr=0, pk=0; /*variaveis auxiliar que indicam os pontos do Ryu (pr) e do Ken (pk) em um certo round*/
	int vr=0, vk=0; /*variaveis auxiliar que indicam as vitorias de Ryu (vr) e Ken (vk)*/
	int i, soma,t; /*variaveis auxiliar para ver se o numero eh primo ou triangular*/
	
	scanf("%d", &g); /*ler golpe*/
	
	while(g>0)
	{
		/*Determinar se o numero � perfeito*/
		for(i=1,soma=0;i<g;i++)
		{
			if(!(g%i)) /*determinar se o numero i � divisor proprio de g*/
			{
				soma=i+soma; /*soma dos divisores proprios*/
			}
		}
		
		/*Ponto de Ryu se o numero for perfeito*/
		if(soma==g)
		{
			pr=(g*3)+pr;
     	}
		
		/*Se o numero nao for perfeito*/
		else
		{
			/*Determinar se o numero � triangular*/
			for(i=1,soma=0,t=0;i<=g;i++)
			{
				soma=i+soma; /*soma dos inteiros menores ou igual a g*/
				
				if(soma==g)
				{
					t=1; /*� triangular*/
				}
			}
			/*Pontos de Ryu se o numero for triangular*/
			if(t==1)
			{
				pr=(g*2)+pr;
			}
			/*Pontos de Ryu se o numero nao tem nenhuma das propriedades anteriores*/
			else
			{
				pr=g+pr;
			}
        }
				
		scanf("%d", &g); /*ler novo golpe*/
		
		while(g<0)
		{
			/*Pontos feitos por Ken*/
			g=-g;
			for(i=1,soma=0;i<g;i++)
			{
				if(!(g%i))
				{
					soma=i+soma;
				}
			}
			/*Numero perfeito*/
			if(soma==g)
			{
				pk=(g*3)+pk;
			}
			/*Numero nao perfeito*/
			else
			{
				for(i=1,soma=0,t=0;i<=g;i++)
				{
					soma=i+soma;
					if(soma==g)
					{
						t=1;
					}
				}
				/*Numero triangular*/
				if(t==1)
				{
					pk=(g*2)+pk;
				}
				/*Nenhuma das propriedades anteriores*/
				else
				{
					pk=g+pk;
				}
		    }
						
			scanf("%d", &g); /*ler novo golpe*/
			
			/*Final de um round ou final da luta*/
			if(g>=0)
			{
				/*Determinar quem venceu o round e acumular vitorias conquistadas*/
				if(pr>pk) /*Ryu venceu o round*/
					vr=1+vr; /*Vitorias de Ryu na luta*/
				if(pk>pr) /*Ken venceu o round*/
					vk=1+vk; /*Vitorias de Ken na luta*/
				
				/*Iniciar  novo round*/	
				pr=0;
				pk=0;
			}
		}
	}
	
	/*Imprimir na tela o resulatdo da luta*/
	if(vr>vk)
		printf("Ryu venceu\n");
	else if(vk>vr)
		printf("Ken venceu\n");
	else
		printf("empatou\n");
	
	return 0;
}
			
				
					
		
		
	
