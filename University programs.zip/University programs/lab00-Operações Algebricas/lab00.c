/*Leonardo Falcao Sabra-RA178441
 Lab00-Apresentacao do susy
 Entrada: dois numeros inteiros
 Saida: Soma,subtracao,multiplicacao,divisao inteira e fracionaria
 Objetivo: Aprender a usar o susy fazendo programa para operacoes*/

#include <stdio.h> /*declarar biblioteca*/
int main()
{
  int n1,n2,soma,subt,mult,div_int;/*declarar variaveis inteiras*/
  float div_frac;/*declarar variavel real*/
  
  printf("Entre com dois inteiros\n");
  scanf("%d %d", &n1, &n2);
  
  /*Operacoes*/
  soma = n1 + n2;
  subt = n1 - n2; 
  mult = n1 * n2;
  div_int = n1 / n2;
  div_frac = n1 / (float) n2;
  
  /*Mostrar resultado das operacoes na tela*/
  printf("Soma = %d\n", soma);
  printf("Diferenca = %d\n", subt);
  printf("Multiplicacao = %d\n", mult);
  printf("Divisao Inteira = %d\n", div_int);
  printf("Divisao = %.2f\n", div_frac);
  return 0;
}
  
