/*Leonardo Falcao Sabra-RA178441
  Lab05-PIB
  Entrada: quantidade de anos a ser considerado e PIB de cada ano
  Saida: qual o primeiro e ultimo ano que teve maior crescimento percentual medio do PIB e quanto foi esse crescimento
  Objetivo: determinar o trienio que teve maior crescimento medio do PIB*/
  
#include <stdio.h>
int main()
{
	/*variaveis de entrada*/
	int n; /*indica a quantidade de anos*/
	float pib; /*indica o PIB*/
	
	/*variaveis de saida*/
	int x, y; /*correspondem ao primeiro(x) e ultimo(y) ano do trienio com maior crescimento medio*/
	float z; /*maior crescimento medio percentual entre os trienios*/
	
	/*variaveis auxiliar*/
	int a; /*indica o ano que vai de 0 a n*/
    float sc, cm; /*correspondem a soma do crescimento do PIB em um trienio(sc) e o crescimento medio do PIB em um trienio(cm)*/
    float cres1, cres2=0, cres3=0; /*variaveis que guardam o crescimento do PIB em 3 anos consecutivos*/
    float pant; /*auxiliar que guarda o PIB do ano a-1 para calcular o crescimento do PIB do ano a*/
    
	scanf("%d", &n);
	
	for(a=0;a<n;a++)
	{
		scanf("%f", &pib);
		
		/*Calculo do cresmiento percentual do PIB em cada ano*/
		if(a==0)
			cres1=0;
		else
			cres3=((pib/pant)-1)*100;
			
		pant=pib;
		
		/*Fazer a soma de um trienio*/
		sc=cres1+cres2+cres3;
		cres1=cres2;
		cres2=cres3;
				
		if(a>=2)
	    {
		    /*Calculo do crescimento percentual medio do PIB em um trienio*/
		    cm=sc/3;
		    
		    /*Atribuir um valor inicial para z, x e y*/
		    if(a==2)
		    {
		       z=cm;
			   x=a-2;
			   y=a;
		    }
		    	    
		    /*Guardar o trienio de maior media de crescimento e qual foi esse crescimento*/
		    if(cm > z)
		    {
		      	z=cm;
		      	x=a-2;
		      	y=a;
		    }
	    }
	}
	printf("a maior media de crescimento foi entre os anos %d e %d: %.1f\n", x, y, z);
	
	return 0;
}
		
		
		
	
