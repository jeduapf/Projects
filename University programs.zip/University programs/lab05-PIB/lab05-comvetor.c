/*Leonardo Falcao Sabra-RA178441
  Lab05-PIB
  Entrada: quantidade de anos a ser considerado e PIB de cada ano
  Saida: qual o primeiro e ultimo ano que teve maior crescimento percentual medio do PIB e quanto foi esse crescimento
  Objetivo: determinar o trienio que teve maior crescimento medio do PIB*/
  
#include <stdio.h>
int main()
{
	/*variaveis de entrada*/
	int n; /*indica a quantidade de anos*/
	float pib; /*indica o PIB*/
	
	/*variaveis de saida*/
	int x, y; /*correspondem ao primeiro(x) e ultimo(y) ano do trienio com maior crescimento medio*/
	float z; /*maior crescimento medio percentual entre os trienios*/
	
	/*variaveis auxiliar*/
	int a; /*indica o ano que vai de 0 a n*/
    float cres[100], cm; /*correspondem ao crescimento do PIB em um ano(cres[a]) e o crescimento medio do PIB em um trienio(cm),a quantidade de anos a ser considerada é ate um seculo */
    float ant; /*auxiliar para calcular o crescimento do PIB*/
    
	scanf("%d", &n);
	
	for(a=0;a<n;a++)
	{
		scanf("%f", &pib);
		
		/*Calculo do cresmiento percentual do PIB em cada ano*/
		if(a==0)
			cres[a]=0;
		else
			cres[a]=((pib/ant)-1)*100;
			
		ant=pib;
	}
	
	for(a=0;a<(n-2);a++)
	{
		/*Calculo do crescimento percentual medio do PIB em um trienio*/
		cm=(cres[a]+cres[a+1]+cres[a+2])/3;
		
		/*Atribuir um valor inicial para z, x e y*/
		if(a==0)
		{
			z=cm;
			x=a;
			y=a+2;
		}
		
		/*Guardar o trienio de maior media de crescimento e qual foi esse crescimento*/
		if(cm > z)
		{
			z=cm;
			x=a;
			y=a+2;
		}
	}
	printf("a maior media de crescimento foi entre os anos %d e %d: %.1f\n", x, y, z);
	
	return 0;
}
		
		
		
	
