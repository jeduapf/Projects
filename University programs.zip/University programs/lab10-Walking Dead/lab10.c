/*Leonardo Falcao Sabra-RA178441
  Lab10-Walking Dead
  Entrada: numero de linhas e colunas da matriz que representa o estado da populacao,
          numero de dias que deseja simular o estado da populacao e numeros inteiros para
          compor a matriz representando vazio(0), homem(1) ou zumbi(2)
  Saida: estado da populacao para cada um dos dias que deeja simular
  Objetivo: dado um estado da populacao ininial simular seu estado final para certo numero de dias de acordo com interacoes humano zumbi estabelecidas*/
  
#include <stdio.h>
int main()
{
	int m, n; /*quantidade de linhas(m) e colunas(n) da matriz*/
	int i; /*quantidade de dias para simulacao*/
	int epi[52][52], epf[52][52]; /*matirz do estado da populacao inicial(epi) e final(epf)*/
	int l, c; /*variaveis auxiliares para 'andar' nas linhas(l) e colunas(c) da matriz*/
	int h=0, z=0; /*variaveis auxiliares para determinar se o elemento da matriz � humano(h) ou zumbi(z)*/
	int x; /*variavel que determina o ano da iteracao simulada que vai de 0 a i*/
	
	scanf("%d %d", &m, &n); /*ler tamanho da matriz*/
	
	scanf("%d", &i); /*ler numero de dias que deseja simular*/
	
	/*Criar a primeira matriz do estado da populacao*/
	for(l=0;l<m+2;l++)
	{
		for(c=0;c<n+2;c++)
		{
			if(l==0 || l==m+1 || c==0 || c==n+1) /*criar 'vizinhos vazio' para os elementos das estremidades da matriz do estado da populacao*/
			{
				epf[l][c]=0;
				epi[l][c]=0;
			}
			else
			{
				scanf("%d", &epf[l][c]); /*ler o elementos inseridos pelo usuario*/
			}
		}
	}
	
	for(x=0;x<=i;x++) /*Variar os anos da simulacao de 0 a i*/
	{
		for(l=1;l<m+1;l++) 
		{
			for(c=1;c<n+1;c++)
			{
				epi[l][c]=epf[l][c]; /*No inicio de cada ano fazer o estado da populcao inicial ser igual a final*/
			}
		}
		
		printf("iteracao %d\n", x);
		
		/*Imprimir na tela a estado da populcao no ano x e simular o estado da populacao no ano x+1*/
		for(l=1;l<m+1;l++)
		{
			for(c=1;c<n+1;c++)
			{
				printf("%d", epf[l][c]); /*imprimir os elementos do estado da populacao final do ano x*/
				
				if(x!=i) /*nao simular o ano i+1*/
				{
					/*Fazer a contagem de elementos vizinhos ao elemneto epi[l][c] que sao humanos e zumbis*/
					switch(epi[l-1][c-1])
					{
						case 1: h++; break;
						case 2: z++; break;
					}
					switch(epi[l-1][c])
					{
						case 1: h++; break;
						case 2: z++; break;	
					}
					switch(epi[l-1][c+1])
					{
						case 1: h++; break;
						case 2: z++; break;					    
			    	}
			    	switch(epi[l][c-1])
			    	{
			    		case 1: h++; break;
			    		case 2: z++; break;					    
			    	}
			    	switch(epi[l][c+1])
			    	{
				    	case 1: h++; break;
				    	case 2: z++; break;					    
				    }
			    	switch(epi[l+1][c-1])
			    	{
			    		case 1: h++; break;
			    		case 2: z++; break;					    
			    	}
			    	switch(epi[l+1][c])
			    	{
			    		case 1: h++; break;
				    	case 2: z++; break;					    
				    }
			    	switch(epi[l+1][c+1])
			    	{
			    		case 1: h++; break;
			    		case 2: z++; break;					    
			    	}
				
			    	/*Simular o que � esperado que ocorra com elemento epi[l][c] no ano x+1*/										
			    	if(epi[l][c]==1 && z!=0) /*Se for um humano e possuir pelo menos um vizinho zumbi*/
			    	{
			    		epf[l][c]=2; /*vira zumbi*/
			    	}
			    	else if(epi[l][c]==2 && (h>=2 || h==0)) /*Se for um zumbi e possuir dois ou mais viznho humanos ou se nao possuir vizinhos humano*/
			    	{
			    		epf[l][c]=0; /*fica vazio*/
			    	}
			    	else if(epi[l][c]==0 && h==2)/*Se for vazio e possuir exatamente dois vizinhos humanos*/
			    	{
			    		epf[l][c]=1; /*surge um humano*/
			    	}
				
			    	/*Reiniciar a contagem de humanos e zumbis para um novo elemento da matriz*/
			    	h=0; z=0;	
				}
		   	}
	    	printf("\n");		
	   	}		
   	}    	
    
	return 0;
}
		
