#include <stdio.h>
int main()
{
  int n, i, j, k=0;
  
  printf("Digite o numero de linhas"); scanf("%d", &n);
  
  printf("Triangulo de Floyd:\n");
  for(i=0;i<n;i++)
  {
  	for(j=0;j<=i;j++)
  	{
  		k++;
  		printf("%3d", k);
  	}
  	printf("\n");
  }
  return 0;
}
