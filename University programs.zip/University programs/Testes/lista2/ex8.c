#include <stdio.h>
int main()
{
  int m, n, i, j;
  
  printf("Digite o numero de linhas e colunas:");
  scanf("%d %d", &m, &n);
  
  for(i=1;i<m;i++)
  {
    for(j=1;j<=n;j++)
    {
    	printf("%d\t",j*i);
    }
    printf("\n");
  }
  
  return 0;
}
      
