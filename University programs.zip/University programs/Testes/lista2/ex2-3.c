#include <stdio.h>
int main()
{
	int s, n1, n5, n10, n50, n100, r;
	int q1, q5, q10, q50, q100, i;
	
	printf("Quantidade de cada nota:\n");
	printf("Nota de 1.00:"); scanf("%d",&q1);
	printf("Nota de 5.00:"); scanf("%d",&q5);
	printf("Nota de 10.00:"); scanf("%d",&q10);
	printf("Nota de 50.00:"); scanf("%d",&q50);
	printf("Nota de 100.00:"); scanf("%d",&q100);
	
	printf("Saque:"); scanf("%d", &s);
	
	n100=s/100;
	r=s%100;
	for(i=0;n100>q100;i++)
	{
		n100=(s-100*i)/100;
		r=(s%100)+100*i;
	}
		
	n50=r/50;
	r=r%50;
	for(i=0;n50>q50;i++)
	{
		n50=(s-50*i)/50;
		r=(s%50)+50*i;
	}
	
	n10=r/10;
	r=r%10;
	for(i=0;n10>q10;i++)
	{
		n10=(s-10*i)/10;
		r=(s%10)+10*i;
	}
	
	n5=r/5;
	r=r%5;
	for(i=0;n5>q5;i++)
	{
		n5=(s-5*i)/5;
		r=(s%5)+5*i;
	}
	
	n1=r;
	
	if(n1>q1)
	{
		printf("Nao ha dinheiro suficiente para saque");
	}
	else
	{
		printf("Total de cedulas = %d\n", n1+n5+n10+n50+n100);
		printf("Cedulas de 1.00 = %d\n", n1);
		printf("Cedulas de 5.00 = %d\n", n5);
		printf("Cedulas de 10.00 = %d\n", n10);
		printf("Cedulas de 50.00 = %d\n", n50);
		printf("Cedulas de 100.00 = %d\n", n100);
	}
	
	return 0;
}
