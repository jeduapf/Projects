#include <stdio.h>
int main()
{
  float a, r, ant=1;
  int n, i;
  
  printf("Inevestimento inicial:"); scanf("%f", &a);
  printf("Numero de meses:"); scanf("%d", &n);
  printf("Juros:"); scanf("%f", &r);
  
  printf("Numero de Meses   Investimento Acumulado\n");
  for(i=1;i<=n;i++)
  {
    ant=a*(1+r)*ant;
    printf("\t%d\t\t%.2f\n", i, ant);
  }
  return 0;
}
  
