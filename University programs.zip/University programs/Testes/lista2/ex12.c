#include <stdio.h>
int main()
{
  int n, i, j, k;
  printf("Digite o numero de linhas;"); scanf("%d", &n);
  
  printf("Tabela:\n");
  for(i=0;i<n;i++)
  {
  	for(k=n-i,j=0;j<(n-i);j++)
  	{
  		printf("%3d", k);
  		k--;
  	}
  	printf("\n");
  }
  return 0;
}
