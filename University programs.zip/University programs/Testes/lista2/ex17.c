#include <stdio.h> 
int main()
{
	int n, p, x, i, somap=0, soma=0;
	
	printf("Digite a quantidade de pares de numeros:"); scanf("%d", &n);
	
	printf("Digite os pares p x:\n");
	for(i=0;i<n;i++)
	{
		scanf("%d %d", &p, &x);
		somap=(p*x)+somap;
		soma=p+soma;
	}
	printf("Media ponderada = %d\n", somap/soma);
	
	return 0;
}
		
		
