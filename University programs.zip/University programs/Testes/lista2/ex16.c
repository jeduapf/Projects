#include <stdio.h> 
int main()
{
	char s;
	int cont=0, m5=0;
	
	printf("Digite o texto terminado em #:\n");
	do
	{
		scanf("%c", &s);
		switch(s)
		{
			case ' ': case ',': case '.': case '#':
				if(cont<=5 && cont!=0)
				{
					m5++;
				}
				cont=0; break;
			default:
			cont++; break;
		}
	}
	while(s!='#');
	
	printf("Numero de palavras com comprimento menor ou igual a 5 = %d", m5);
	
	return 0;
}
	

		
