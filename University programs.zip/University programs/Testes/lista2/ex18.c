#include <stdio.h> 
int main()
{
	int n, i, e=1;
	printf("Digite o numero de termos da aproximacao linear:"); scanf("%d", &n);
	
	printf("0|x e^(-u^2) du = ");
	for(i=0;i<n;i++)
	{
		if(i==0)
		{
			printf("x-");
		}
		else
		{
			printf("x^%d/%d*%d!", e, e, i);
			if(i%2)
			{
				printf("+");
			}
			else
			{
				printf("-");
			}
		}
		e=e+2;
	}
	printf("...\n");
	return 0;
}
