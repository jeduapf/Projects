#include <stdio.h>
int main()
{
 int n, num;
 int i, soma=0, max, min;
 
 printf("Digite a quantidade de numeros:");
 scanf("%d", &n);
 
 printf("Digite os numeros:\n");
 for(i=0;i<n;i++)
 {
   scanf("%d", &num);
   
   soma=num+soma;
   
   /*Iniciar variaveis de maximo e minimo*/   
   if(i==0)
   {
     max=num;
     min=num;
   }
   if(num>max)
   {
     max=num;
   }
   if(num<min)
   {
     min=num;
   }
 }
 
 printf("Media:%d\nMaior:%d\nMenor:%d\n", soma/n, max, min);
 
 return 0;
}
  
