#include <stdio.h>
int mdc(int m, int n);
int main()
{
	int m, n;
	scanf("%d %d", &m, &n);
	printf("mdc(%d,%d)=%d", m, n, mdc(m,n));
}
int mdc(int m, int n)
{
	int aux;
	while(n!=0)
	{
		aux=m;
		m=n;
		n=aux%n;
	}
	return m;
}
	
	
