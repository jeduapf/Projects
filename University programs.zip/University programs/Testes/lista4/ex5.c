#include <stdio.h>
int teste(int a, int b, int n);
int pitagorico(int n);
int main()
{
	int n;
	scanf("%d", &n);
	printf("%d", pitagorico(n));
	return 0;
}

int pitagorico(int n)
{
	int p, a, b;
	for(a=2;a<n;a++)
	{
		for(b=2;b<n;b++)
		{
			if(teste(a,b,n))
			{
				return 1;
			}
		}
	}
    return 0;
}
int teste(int a, int b, int n)
{
	if(a*a+b*b==n)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}		

