#include <stdio.h>
int menor_base_log(int n);
int main()
{
	int n;
	scanf("%d", &n);
	printf("%d", menor_base_log(n));
	return 0;
}
int menor_base_log(int n)
{
	int b, p;
	for(b=2;p!=n;b++)
	{
		p=1;
		while(p<n)
		{
			p=p*b;
		}		
	}
	return b-1;		
}
