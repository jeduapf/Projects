#include <stdio.h>
double media(double v[], int tam);
int main()
{
	int tam, i;
	double r[20];
	scanf("%d", &tam);
	for(i=0;i<tam;i++)
	{
		scanf("%lf", &r[i]);
	}
	printf("%.2lf", media(r,tam));
}
double media(double v[], int tam)
{
	int i;
	double m=0;
	for(i=0;i<tam;i++)
	{
		m=v[i]+m;
	}
	m=m/tam;
	return m;
}
