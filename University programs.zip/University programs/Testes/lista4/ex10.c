#include <stdio.h>
void multiplica(double mat1[30][30], double mat2[30][30], double matRes[30][30], int n);
int main()
{
	double mat1[30][30], mat2[30][30], matRes[30][30];
	int n, i, j;
	scanf("%d", &n);
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%lf", &mat1[i][j]);
		}
	}
		for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%lf", &mat2[i][j]);
		}
	}
	multiplica(mat1,mat2,matRes,n);
	return 0;
}
void multiplica(double mat1[30][30], double mat2[30][30], double matRes[30][30], int n)
{
	int i, j, k, s;
	for(i=0;i<n;i++)
	{
		for(k=0;k<n;k++)
		{
			for(j=0,s=0;j<n;j++)
			{
				matRes[i][k]=mat1[i][j]*mat2[j][k]+s;
				s=matRes[i][k];
			}
		    printf(" %.1lf", matRes[i][k]);
		}
		printf("\n");
	}
	return;
}
	
