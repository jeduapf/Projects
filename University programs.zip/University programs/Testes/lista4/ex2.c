#include <stdio.h>
int amigos(int a, int b);

int main()
{
	int a, b;
	scanf("%d %d", &a, &b);
	printf("%d\n", amigos(a,b));
	
	return 0;
}

int amigos(int a, int b)
{
	int i, sa=0, sb=0;
	for(i=1;i<a;i++)
	{
		if(!(a%i))
		{
			sa=i+sa;
		}
	}
	for(i=1;i<b;i++)
	{
		if(!(b%i))
		{
			sb=i+sb;
		}
	}
	if(sa==b && sb==a)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
