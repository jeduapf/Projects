#include <stdio.h>
int magico(int mat[30][30], int n);
int main()
{
	int mat[30][30], n, i, j;
	scanf("%d", &n);
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d", &mat[i][j]);
		}
	}
	printf("%d", magico(mat,n));
	return 0;
}
int magico(int mat[30][30], int n)
{
	int i, j, sdp=0, sds=0, sl, sc;
	for(i=0;i<n;i++)
	{
		sdp=mat[i][i]+sdp;
		sds=mat[i][n-i-1]+sds;
	}
	if(sdp==sds)
	{
		for(i=0;i<n;i++)
		{
			for(j=0,sl=0,sc=0;j<n;j++)
			{
				sl=mat[i][j]+sl;
				sc=mat[j][i]+sc;
			}
			if(sl!=sdp || sc!=sdp)
			{
				return 0;
			}
    	}
	}
	else	
		return 0;
	return 1;
	
}
	
		
		
