#include <stdio.h>
void verifica(int mat[30][30], int n, int respota[]);
int main()
{
	int mat[30][30], n, resposta[100], i, j;
	scanf("%d", &n);
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d", &mat[i][j]);
		}
	}
	verifica(mat,n,resposta);
	return 0;
}
void verifica(int mat[30][30], int n, int resposta[])
{
	int i, j, e[30], s[30];
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			if(mat[i][j]==1)
			{
				s[i]=1;
			}
			if(mat[j][i]==1)
			{
				e[i]=1;
			}
		}			
	}
	printf("Cidades com entrada e sem saida:\n");
	for(i=0;i<n;i++)
	{
		if(e[i]==1 && s[i]==0)
		{
			printf("Cidade %d=1\n",i);
		}
		else
		{
			printf("Cidae %d=0\n", i);
		}
	}
	printf("Cidades com saida e sem entrada:\n");
	for(i=0;i<n;i++)
	{
		if(e[i]==0 && s[i]==1)
		{
			printf("Cidade %d=1\n",i);
		}
		else
		{
			printf("Cidade %d=0\n", i);
		}
	}
	printf("Cidades isoladas:\n");
	for(i=0;i<n;i++)
	{
		if(e[i]==0 && s[i]==0)
		{
			printf("Cidade %d=1\n",i);
		}
		else
		{
			printf("Cidade %d=0\n", i);
		}
	}
}
	
	
		
