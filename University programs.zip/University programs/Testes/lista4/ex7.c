#include <stdio.h>
#include <math.h>
double desvioPadrao(double v[], int tam);
int main()
{
	double v[20];
	int tam, i;
	scanf("%d", &tam);
	for(i=0;i<tam;i++)
	{
		scanf("%lf", &v[i]);
	}
	printf("%.2lf", desvioPadrao(v,tam));
	return 0;
}
double desvioPadrao(double v[], int tam)
{
	int i;
	double s=0,s2=0;
	for(i=0;i<tam;i++)
	{
		s2=v[i]*v[i]+s2;
		s=v[i]+s;
	}
	s=sqrt((s2-(s*s)/tam)/(tam-1));
	return s;
}
	
		
	
