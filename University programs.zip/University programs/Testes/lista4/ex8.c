#include <stdio.h>
void transposta(double mat1[30][30], double matRes[30][30], int n);
int main()
{
	double mat1[30][30], matRes[30][30];
	int n, i, j;
	scanf("%d", &n);
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%lf", &mat1[i][j]);
		}
	}
	transposta(mat1,matRes,n);
	return 0;
}
void transposta(double mat1[30][30], double matRes[30][30], int n)
{
	int i,j;
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			matRes[i][j]=mat1[j][i];
		}
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			printf(" %.1lf", matRes[i][j]);
		}
		printf("\n");
	}
	return;
}
	
