/*Busca binaria*/
#include <stdio.h>
int main()
{
	int s[100], i=-1, t, j, aux, b, m, d, e, min;
	printf("Digite uma sequencia de numeros terminada em zero:\n");
	
	do
	{
		i++;
		t++;
		scanf("%d", &s[i]);				
	}
	while(s[i]!=0);
	
	/*Ordenar*/
	for(i=0;i<t;i++)
	{
		min=i;
		for(j=i+1;j<t;j++)
		{
			if(s[j]<s[min])
			{
				min=j;
			}
		}
		aux=s[i];
		s[i]=s[min];
		s[min]=aux;
	}
	printf("Digite o numero da busca:\n");
	scanf("%d", &b);
	m=t/2;
	e=0;
	d=t;
	while(b!=s[m] && e<d)
	{
		if(b>s[m])
		{
			e=m+1;
		}
		else
		{
			d=m-1;
		}
		m=(d+e)/2;
	}
	if(s[m]==b)
	{
		printf("O numero ocorre na sequencia\n");		
	}		
	else
	{
		printf("O numero nao ocorre na sequencia\n");
	}
	return 0;
}


