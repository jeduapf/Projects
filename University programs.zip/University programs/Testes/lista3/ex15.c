#include <stdio.h>
int main()
{
	int mat[50][50], m, n, i, j; 
	float mat1[50][50];
	
	printf("Digite o numero de linhas e colunas: ");
	scanf("%d %d", &m, &n);
	
	printf("Digite a matriz:\n");
	for(i=0;i<m+2;i++)
	{
		for(j=0;j<n+2;j++)
		{
			if(i==0 || i==m+1 || j==0 || j==n+1)
			{
				mat[i][j]=0;
			}
			else
			{
				scanf("%d", &mat[i][j]);
			}
		}
	}
	printf("A matriz com a media dos elementos adjacentes:\n");
	for(i=1;i<m+1;i++)
	{
		for(j=1;j<n+1;j++)
		{
			if(i==1 || i==m || j==1 || j==n)
			{
				if((i==1 || i==m) && (j==1 || j==n))
				{
					mat1[i][j]=(float) (mat[i-1][j-1]+mat[i-1][j]+mat[i-1][j+1]+mat[i][j-1]+mat[i][j+1]+mat[i+1][j-1]+mat[i+1][j]+mat[i+1][j+1])/3;
				}
				else
				{
					mat1[i][j]=(float) (mat[i-1][j-1]+mat[i-1][j]+mat[i-1][j+1]+mat[i][j-1]+mat[i][j+1]+mat[i+1][j-1]+mat[i+1][j]+mat[i+1][j+1])/5;
				}
			}
			else
			{
				mat1[i][j]=(float) (mat[i-1][j-1]+mat[i-1][j]+mat[i-1][j+1]+mat[i][j-1]+mat[i][j+1]+mat[i+1][j-1]+mat[i+1][j]+mat[i+1][j+1])/8;
			}
			printf("%.1f",mat1[i][j]);
		}
		printf("\n");
	}
	return 0;
}
	
	

