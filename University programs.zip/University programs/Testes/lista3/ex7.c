/*Busca sequencial*/
#include <stdio.h>
int main()
{
	int s[100], i=-1, b, oc=0;
	printf("Digite uma sequencia de numeros terminada em zero:\n");
	do
	{
		i++;
		scanf("%d", &s[i]);		
	}
	while(s[i]!=0);
	
	printf("Digite o numero da busca:\n");
	scanf("%d", &b);
		
	for(i=0;s[i]!=0;i++)
	{
		if(s[i]==b)
		{
			printf("O numero ocorre na sequencia\n");
			oc=1;
		}		
	}
	if(oc==0)
	{
		printf("O numero nao ocorre na sequencia\n");
	}
	return 0;
}
	
	
	
	
	
	
