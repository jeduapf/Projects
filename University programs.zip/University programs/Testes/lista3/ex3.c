#include <stdio.h> 
#include <string.h>
int main()
{
	char n1[100], n2[100], tam1, tam2; 
	int i, j, dif1, dif2, a=1;

	printf("Digite duas palavras: ");
	scanf("%s %s", n1, n2);
	
	tam1=strlen(n1);
	tam2=strlen(n2);
	
	/*Se o tamanho for diferente nao eh anagrama*/
	if(tam1!=tam2)
	{
		printf("Nao eh anagrama");
	}
	else
	{
		for(i=0;i<tam1;i++)
		{
			for(dif1=0,j=0,dif2=0;j<tam1;j++)
			{
				/*Se mesmo tamanho entao nao eh anagrama se um caracter em uma das palavras que nao ocorre na outra*/
				if(n1[i]!=n2[j])
				{
					dif1++;
				}
				if(n2[i]!=n1[j]) 
				{
					dif2++;
				}
				if(dif1==tam1 || dif2==tam1) /*Se o caracter nao occore entao diferente(dif) deve ser igual ao tamanho*/
			    {
			    	a=0; 
                }
			}
     	}
        if(a!=0)
        {
        	printf("Eh anagrama");
        }
        else
        {
        	printf("Nao eh anagrama");
        }
    }
    return 0;
}
	
