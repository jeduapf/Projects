#include <stdio.h>
int main()
{
	int m[50][50], n, i, j;
	printf("Digite o numero de linhas: ");
	scanf("%d", &n);
	
	printf("Triangulo de pascal:\n");
	for(i=0;i<n;i++)
	{
		for(j=0;j<=i;j++)
		{
			if(i==0 || i==1 || j==0 || j==i)
			{
				m[i][j]=1;
				
			}
			else
			{
				m[i][j]=m[i-1][j-1]+ m[i-1][j];
			}
			printf("%3d", m[i][j]);
		}
		printf("\n");
	}
	return 0;
}

	
