#include <stdio.h>
int main()
{
	int n, c[50], p, ni[50],i, nv, t[50];
	printf("Numero de pessoas na empresa: ");
	scanf("%d", &n);	
	for(p=0;p<n;p++)
	{
		printf("Pessoa %d - Chefe ", p);
		scanf("%d", &c[p]);
		if(c[p]==-1)
		{
			ni[p]=1;
		}
	}
	for(nv=2;nv<=n;nv++)
	{
		for(p=0;p<n;p++)
		{
			for(i=0;i<n;i++)
			{
				if(c[p]==i && ni[i]==nv-1)
				{
					ni[p]=nv;
				}
			}
		}
	}
	printf("\n");
	for(i=0;i<n;i++)
	{
		printf("Pessoa %d - Nivel %d\n", i, ni[i]);
	}
	printf("\n");
	for(p=0;p<n;p++)
	{
		printf("Pessoa %d - Tempo ", p);
		scanf("%d", &t[p]);		
	}			
	for(nv=2;nv<=n;nv++)
	{		
		for(p=0;p<n;p++)
		{
			if(ni[p]==nv)
			{
				t[p]=t[p]+t[c[p]];			    
			}
		}
	}
	printf("\n");
	for(i=0;i<n;i++)
	{
	printf("Pessoa %d - Tempo Total %d\n", i, t[i]);
    }     
	return 0;
}
		
			
		
		
			
	
