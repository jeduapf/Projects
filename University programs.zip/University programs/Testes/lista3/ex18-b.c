#include <stdio.h>
int main()
{
	int l[50], la[50], n, i, j;
	printf("Digite o numero de linhas: ");
	scanf("%d", &n);
	
	printf("Triangulo de pascal:\n");
	for(i=0;i<n;i++)
	{
		for(j=0;j<=i;j++)
		{
			if(i==0 || i==1 || j==0 || j==i)
			{
				l[j]=1;				
			}
			else
			{
				l[j]=la[j-1]+la[j];
			}
			printf("%3d", l[j]);			
		}
		printf("\n");
		for(j=0;j<=i;j++)
		{
			la[j]=l[j];
		}
	}
	return 0;
}
