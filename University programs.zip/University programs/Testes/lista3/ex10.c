#include <stdio.h> 
#include <string.h>
int main()
{
	char f[100];
	int i;
	printf("Escreva uma palavra: ");
	gets(f);
	for(i=0;i<strlen(f);i++)
	{
		switch(f[i])
		{
			case ' ': case ',': case '.':
				printf("\n"); break;
			default:
				printf("%c", f[i]); break;
		}
		
	}
	return 0;
}
	
