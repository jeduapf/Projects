#include <stdio.h>
int main()
{
	int m, n, mat[50][50], i, j, s=1;
	scanf("%d %d", &m, &n);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d", &mat[i][j]);
		}
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			if(mat[i][j]!=mat[j][i])
			{
				s=0;
			}
		}
	}
	if(s==1)
	{
		printf("Matriz simetrica\n");
	}
	else
	{
		printf("Matriz nao simetrica");
	}
	return 0;
}
	
