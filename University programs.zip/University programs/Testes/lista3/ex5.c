#include <stdio.h> 
int main()
{
	int n, num, cont=1, i, ant;
	printf("Digite a quantidade de numeros: ");
	scanf("%d", &n);
	
	printf("Digite uma sequencia de numeros: ");
	for(i=0;i<n;i++)
	{
		scanf("%d",&num);
		if(num!=ant)
		{
			cont++;
		}
		ant=num;
	}
	printf("Sequencias isoladas = %d", cont);
	return 0;
}
