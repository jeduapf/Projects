#include <stdio.h>
#include <string.h>
int main()
{
	char p[10];
	int tam, i, k=0;
	
	printf("Digite uma palvra: ");
	scanf("%s", p);
	
	tam=strlen(p);
	
	for(i=0;i<tam;i++)
	{
		if(p[i]==p[tam-1-i])/*Comparar 'primerio' e 'ultimo' caracter*/
		{
			k++;
		}	
	}
	
	if(k==tam)
	{
		printf("Palindromo\n");
	}
	else
	{
		printf("Nao eh palindromo\n");
	}
	return 0;
}
