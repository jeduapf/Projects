#include <stdio.h>
int main()
{
	int i, j, mat[50][50], n, uml, umc, p=1;
	scanf("%d", &n);
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d", &mat[i][j]);
		}
	}
	for(i=0;i<n;i++)
	{
		for(j=0,uml=0,umc=0;j<n;j++)
		{
			if(mat[i][j]==1)
			{
				uml++;
			}
			if(mat[j][i]==1)
			{
				umc++;
			}
		}
		if(uml!=1 || umc!=1)
		{
			p=0;
		}
	}
	if(p==1)
	{
		printf("Matriz de permutacao\n");
	}
	else
	{
		printf("Nao eh matriz de permutacao");
	}
	return 0;
}
	
	
