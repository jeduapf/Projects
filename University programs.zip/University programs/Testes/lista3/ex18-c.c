#include <stdio.h>
int main()
{
	int l[50], n, i, j, aux, aux2=1;
	printf("Digite o numero de linhas: ");
	scanf("%d", &n);
	
	printf("Triangulo de pascal:\n");
	for(i=0;i<n;i++)
	{
		for(j=0;j<=i;j++)
		{
			if(i==0 || i==1 || j==0 || j==i)
			{
				l[j]=1;				
			}
			else
			{
				aux=l[j];
				l[j]=l[j]+aux2;
				aux2=aux;
			}
			printf("%3d", l[j]);			
		}
		printf("\n");
	}
	return 0;
}
