#include <stdio.h> 
int main()
{
	int n, v[100], i, aux;
	
	printf("Digite o tamanho do vetor:");
	 scanf("%d", &n);
	
	printf("Vetor: ");
	for(i=0;i<n;i++)
	{
		scanf("%d", &v[i]);
	}
	for(i=0;i<n/2;i++)
	{
		aux=v[n-i-1];
		v[n-i-1]=v[i];
		v[i]=aux;
	}
	
	printf("Vetor invertido: ");
	for(i=0;i<n;i++)
	{
		printf("%d ", v[i]);
	}
	return 0;
}
	
