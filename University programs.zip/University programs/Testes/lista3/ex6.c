#include <stdio.h>
#include <string.h>
int main()
{
	char n[10], m[20];
	int i, j, l, ig, seq=0;
	printf("Digite duas sequencias de numeros binarios:\n");
	scanf("%s", n);
	scanf("%s", m);
	
	for(i=0;i<=strlen(m)-strlen(n);i++)
	{
		if(n[0]==m[i])/*Ver se o primeiro caracter da primeira sequencia eh igual a algum caracter da segunda*/
		{
			for(j=0,l=i,ig=0;j<strlen(n);j++,l++) /*Se for comparar os demais caracteres*/
			{
				if(n[j]==m[l])
				{
					ig++;
				}
				if(ig==strlen(n))
				{
					seq++;
				}
			}
		}
	}
	printf("A primeira sequencia ocorre %d vezes na segunda\n", seq);
	return 0;
}
					
