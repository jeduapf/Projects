#include <stdio.h>
int amigo(int num);
int main()
{
	int n, num=1, a;
	scanf("%d", &n);
	while(num<=n)
	{
		a=amigo(num);
		if(a!=0 && num<=a)
		{
			printf("%d amigo %d\n", num, a);
		}
		num++;
	}
	return 0;
}
int amigo(int num)
{
	int i, s1=0, s2=0, a=0;
	for(i=1;i<num;i++)
	{
		if(!(num%i))
		{
			s1=s1+i;
		}
	}
		for(i=1;i<s1;i++)
	{
		if(!(s1%i))
		{
			s2=s2+i;
		}
	}
	if(s2==num)
	{
		a=s1;
	}
	return a;
}
	
	
