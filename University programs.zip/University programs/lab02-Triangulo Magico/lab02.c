/* Leonardo Falcao Sabra-RA178441
   Lab01-Triangulo magico
   Entrada: seis lados do triangulo magico
   Saida: resposta se o triangulo eh magico ou nao
   Objetivo: determinar se o triangulo eh ou nao magico*/
   
#include <stdio.h>
int main()
{
	int v1, v2, v3, v4, v5, v6; /* declarar variaveis de entrada */
	
	scanf("%d %d %d %d %d %d", &v1, &v2, &v3, &v4, &v5, &v6); /* ler valores dos lados fornecidos */
	
	if(v1+v2+v3==v3+v4+v5 && v3+v4+v5==v5+v6+v1) /* condicao para ser um triangulo magico */
		printf("sim\n");
	
	else
		printf("nao\n");
		
	return 0;
}
	
	
