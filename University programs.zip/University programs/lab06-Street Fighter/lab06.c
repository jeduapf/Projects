/*Leonardo Falcao Sabra-RA178441
  Lab06-Street Fighter
  Entrada: nuemros inteiros que representam golpes aplicados por Ryu, valores positivos, e Ken, valores negativos
  Saida: resultado da luta, quem venceu ou se houve empate
  Objetivo: determinar em uma luta de determinados raund quem teve mais vitorias e portanto venceu a luta*/
  
#include <stdio.h>
int main()
{
	int g; /*variavel de entrada que indica os golpes*/
	int pr=0, pk=0; /*variaveis auxiliar que indicam os pontos do Ryu (pr) e do Ken (pk) em um certo round*/
	int vr=0, vk=0; /*variaveis auxiliar que indicam as vitorias de Ryu (vr) e Ken (vk)*/
	
	scanf("%d", &g); 
	
	while(g>0)
	{
		/*Pontos feitos por Ryu*/
		pr=g+pr; 
		
		scanf("%d", &g); 
		
		while(g<0)
		{
			/*Pontos feitos por Ken*/
			pk=-g+pk;
			
			scanf("%d", &g);
			
			/*Final de um round ou final da luta*/
			if(g>=0)
			{
				/*Determinar quem venceu o round e acumular vitorias conquistadas*/
				if(pr>pk) /*Ryu venceu o round*/
					vr=1+vr; /*Vitorias de Ryu na luta*/
				if(pk>pr) /*Ken venceu o round*/
					vk=1+vk; /*Vitorias de Ken na luta*/
				
				/*Iniciar  novo round*/	
				pr=0;
				pk=0;
			}
		}
	}
	
	/*Imprimir na tela o resulatdo da luta*/
	if(vr>vk)
		printf("Ryu venceu\n");
	else if(vk>vr)
		printf("Ken venceu\n");
	else
		printf("empatou\n");
	
	return 0;
}
			
				
					
		
		
	
