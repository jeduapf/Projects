/*Leonardo Falc�o Sabra-RA178441
  Lab01-Beta
  Entrada: distancia entre duas cidades, em estadio, e angulo entre elas,em graus
  Saida: comprimento da circunferencia em estadios e quilometros
  Objetivo: Calcular a circunferencia de acordo com o calculo feito por Erastotenes*/

#include <stdio.h>
int main()
{
	float d, a; /*declarar variaveis de entrada*/
	float ce, ckm; /*declarar variaveis de saida*/
	
	scanf("%f %f", &d, &a); /*Ler os valores fornecidos*/

	/*Formulas para o calculo da circunferencia*/
	ce = (360 * d) / a ;   /*resultado em estadios*/
	ckm = (ce * 176.4) / 1000 ;    /*resulatdo em quilometros*/
	
	printf("%.1f\n%.1f\n", ce, ckm); /*imprimir na tela os resultados da circunferencia*/
	
	return 0;
}
	
  
