/* Leonardo Falcao Sabra-RA178441
   Lab04-Jogo da Velha
   Entrada:caracteres que representam o que foi colocado em cada linha do jogo da velha
   Saida:resultado do que ocorreu no jogo, quem ganhou ou se foi empate
   Objetivo:dado um jogo da velha determinar o resultado*/
   
#include <stdio.h>
int main()
{
	char v1, v2, v3, v4, v5, v6, v7, v8, v9; /*declarar variaveis de entrada*/
	
	scanf("%c %c %c %c %c %c %c %c %c", &v1, &v2, &v3, &v4, &v5, &v6, &v7, &v8, &v9); /*ler dados fornecidos*/
	
	/*Possibilidades ganhadoras*/
	if(((v1==v2 && v1==v3) || (v1==v4 && v1==v7) || (v1==v5 && v1==v9)) && (v1!='-')) /*preencher linha 1 ou coluna 1 ou diagonal principal*/
	{
		printf("%c venceu\n", v1);
	}
	else if(((v5==v4 && v5==v6) || (v5==v2 && v5==v8) || (v5==v3 && v5==v7)) && (v5!='-')) /*preencher lina 2 e coluna 2 e diagonal sedundaria*/
	{
		printf("%c venceu\n", v5);
	}
	else if(((v9==v8 && v9==v7) || (v9==v6 && v9==v3)) && (v9!='-')) /*preencher linha3 e coluna 3*/
	{
		printf("%c venceu\n", v9);
	}
	/*Ocorre empate*/
	else 
	{
		printf("empatou\n");
	}
	
	return 0;
}
	
