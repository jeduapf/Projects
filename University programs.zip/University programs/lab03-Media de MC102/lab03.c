/* Leonardo Falcao Sabra-RA178441
   Lab04-Media de MC102
   Entrada: notas das provas, media do laboratorio e se tiver nota do exame
   Saida: media das provas, media antes do exame e nota final
   Obejetivo: calcular para o aluno suas medias e nota final*/
   
#include <stdio.h>
int main()
{
	float p1, p2, Ml, E; /*declarar variaveis de entrada*/
	float Mp, M, F; /*declarar variaveis de saida*/

	/*Ler notas das provas e media do laboratorio fornecidas*/
	scanf("%f %f %f", &p1, &p2, &Ml);
	
	/*Formula para calculo da media das provas*/
	Mp = (2*p1 + 3*p2) / 5;
	
	/*Calculo da media antes do exame*/
	if(Mp==0 && Ml==0)
		M = 0;
	else
		M = (3*Mp*Ml) / (Mp+2*Ml);
		
	/*Calculo da nota final*/	
	if(M>=2.5 && M<5) /*foi para exame*/
	{
		scanf("%f", &E); /*ler nota do exame*/
		
		/*Calculo da nota com exame*/
		F = (M + E) / 2;
		if(F > 5)
			F = 5;
	}
	else  /*nao precisa de exame ou nao atingiu nota minima para exame*/
		F = M;
			
	/*Colocar resulatdo das medias e nota final na tela*/
	printf("%.1f\n%.1f\n%.1f\n", Mp, M, F);
	
	return 0;
}
	
