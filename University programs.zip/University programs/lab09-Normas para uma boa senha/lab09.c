/*Leonardo Falcao Sabra-RA178441
  Lab09-Normas para uma boa senha
  Entrada: numero inteiro especificando quantidades de palavras reservadas que compoe o dicionario,
           as palvras que compoe o dicionario e a senha digitada pelo usuario
  Saida: indicar os erros encontrados na senha caso ocorra ou indicar que a senha esta ok
  Objetivo: dada uma senha digitada pelo usuario indicar se ela esta em acordo com criterios determinados*/
  
#include <stdio.h>
#include <string.h>
#include <ctype.h>
int main()
{
	int n; /*indicar quantidades de palvras que compoe o dicionario*/
	char d[50][21]; /*matriz de string que guarda as palavras reservadas do dicionario*/
	char s[51]; /*string que guarda a senha digitada pelo usuario*/
	
	/*variaveis auxiliares*/	
	int ma=0, mi=0, num=0, simb=0; /*indicar se tem letra maiuscula(ma), minuscula(mi), numero(num) e simbolo(simb)*/
	int p=0, prd=1; /*indicar se a senha � palindromo(p), indicar se contem palavras reservadas do dicionario(prd)*/
	int erro=0; /*indicar se houve ou nao erro na senha*/
	int tams, tamd; /*numero de caracteres da senha(tams) e das palvras do dicionario(tamd)*/
	int i, j, k, l; /*auxiliares para verificar a ocorrencia de erros na senha e para fazer a matriz do dicionario(i)*/		
	
	scanf("%d", &n);
	
	for(i=0;i<n;i++)
	{
		scanf("%s", d[i]); /*Fazer a matriz dicionario com as palavras reservadas em cada linha*/
	}
	
	scanf("%s", s); /*ler a senha digitada pelo usuario*/
	
	tams=strlen(s); /*Calcular o tamanho da senha*/
	
	for(i=0;i<tams;i++)
	{
		if(isupper(s[i])) /*Identificar letra maiuscula*/
			ma=1;
		if(islower(s[i])) /*Identificar letra minuscula*/
			mi=1;
		if(isdigit(s[i])) /*Identificar numero*/
			num=1;
		if((s[i]=='!') || (s[i]=='?') || (s[i]=='#') || (s[i]=='@') || (s[i]=='$')) /*Identificar simbolo*/
			simb=1;
		if(s[i]==s[tams-1-i]) /*Identificar palindromo*/
			p++; /*contar quantas palvras iguais ocorreu*/
	}
	
	/*Verificar se houve erro na senha e imprimir na tela qual o erro encontrado*/
	if(tams<8)
	{
		printf("A senha deve conter pelo menos 8 caracteres\n");
		erro=1;
	}
	if(ma!=1)
	{
		printf("A senha deve conter pelo menos uma letra maiuscula\n");
		erro=1;
	}
	if(mi!=1)
	{
		printf("A senha deve conter pelo menos uma letra minuscula\n");
		erro=1;
	}
	if(num!=1)
	{
		printf("A senha deve conter pelo menos um numero\n");
		erro=1;
	}
	if(simb!=1)
	{
		printf("A senha deve conter pelo menos um simbolo\n");
		erro=1;
	}
	if(p==tams)
	{
		printf("A senha e um palindromo\n");
		erro=1;
	}
	for(i=0;i<n;i++) /*Verificar se contem palavras reservadas na senha*/
	{
		tamd=strlen(d[i]); /*Calcular o tamanho da palvra na linha i da matriz dicionario*/
		
		for(j=0;j<=(tams-tamd);j++)
		{
			if(d[i][0]==tolower(s[j])) /*Ver se o primeiro caracter da palvra reservada � igual a algum caracter da senha*/
			{
				for(k=1,l=j+1;k<tamd;k++,l++) /*Caso seja igual ver se todos os demais caracteres da palavra reservada sao iguais ao da senha*/
				{
					if(d[i][k]==tolower(s[l]))
					{
						prd++; /*contar quantas palavras iguais ocorreu*/
					}
				}
				if(prd==tamd)
				{
					printf("A senha nao pode conter palavras reservadas\n");
					erro=1;
				}
				prd=1;
			}
		}
	}
	
	if(erro==0) /*Nao ocorreu erro*/
	{
		printf("ok\n");
	}
	
	return 0;
}
	
	
